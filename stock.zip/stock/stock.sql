-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2021 at 11:38 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `brand_active` int(11) NOT NULL DEFAULT 0,
  `brand_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_name`, `brand_active`, `brand_status`) VALUES
(1, 'Gap', 1, 2),
(2, 'Forever 21', 1, 2),
(3, 'Gap', 1, 2),
(4, 'Forever 21', 1, 2),
(5, 'Adidas', 1, 2),
(6, 'Gap', 1, 2),
(7, 'Forever 21', 1, 2),
(8, 'Adidas', 1, 2),
(9, 'Gap', 1, 2),
(10, 'Forever 21', 1, 2),
(11, 'Adidas', 1, 1),
(12, 'Gap', 1, 1),
(13, 'Forever 21', 1, 1),
(14, 'Italia', 1, 1),
(15, 'ADIDAS', 1, 1),
(16, 'ITARA', 1, 1),
(17, 'NILE', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL,
  `categories_name` varchar(255) NOT NULL,
  `categories_active` int(11) NOT NULL DEFAULT 0,
  `categories_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categories_id`, `categories_name`, `categories_active`, `categories_status`) VALUES
(1, 'Sports ', 1, 2),
(2, 'Casual', 1, 2),
(3, 'Casual', 1, 2),
(4, 'Sport', 1, 2),
(5, 'Casual', 1, 2),
(6, 'Sport wear', 1, 2),
(7, 'Casual wear', 1, 1),
(8, 'Sports ', 1, 1),
(9, 'mini swicth', 1, 1),
(10, 'telecom', 1, 1),
(11, 'AMAMI ANE', 1, 1),
(12, '1L', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mainstock`
--

CREATE TABLE `mainstock` (
  `product_id` int(11) NOT NULL DEFAULT 0,
  `product_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `product_image` text CHARACTER SET latin1 NOT NULL,
  `brand_id` int(11) NOT NULL,
  `categories_id` varchar(250) CHARACTER SET latin1 NOT NULL,
  `quantity` varchar(255) CHARACTER SET latin1 NOT NULL,
  `rate` varchar(255) CHARACTER SET latin1 NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mainstock`
--

INSERT INTO `mainstock` (`product_id`, `product_name`, `product_image`, `brand_id`, `categories_id`, `quantity`, `rate`, `active`, `status`) VALUES
(1, 'Half pant', '../assests/images/stock/2847957892502c7200.jpg', 1, '2', '19', '1500', 2, 2),
(2, 'T-Shirt', '../assests/images/stock/163965789252551575.jpg', 2, '2', '9', '1200', 2, 2),
(3, 'Half Pant', '../assests/images/stock/13274578927924974b.jpg', 5, '3', '18', '1200', 2, 2),
(4, 'T-Shirt', '../assests/images/stock/12299578927ace94c5.jpg', 6, '3', '29', '1000', 2, 2),
(5, 'Half Pant', '../assests/images/stock/24937578929c13532e.jpg', 8, '5', '17', '1200', 2, 2),
(6, 'Polo T-Shirt', '../assests/images/stock/10222578929f733dbf.jpg', 9, '5', '29', '1200', 2, 2),
(7, 'Half Pant', '../assests/images/stock/92406141361bb3831e0740.PNG', 11, '7', '28', '1200', 2, 2),
(8, 'Polo T-shirt', '../assests/images/stock/136715789347d1aea6.jpg', 12, '7', '20', '1200', 1, 1),
(9, 'umuceri', '../assests/images/stock/74249247061b9c1c8a5c1a.jpg', 11, '7', '96', '1000', 1, 1),
(10, 'SOCKET', '../assests/images/stock/168947759361b9c372c9eda.jpg', 13, '8', '118', '200', 1, 1),
(11, 'Itara', '../assests/images/stock/152488317361ba01c5ec684.jpg', 13, '8', '6', '40000', 1, 1),
(12, 'vbbbbbbbbb', '../assests/images/stock/64833731761ba35a86572b.jpg', 14, '9', '2', '444444', 1, 1),
(13, 'swiitch', '../assests/images/stock/15000412561bb10ca189f1.jpg', 12, '8', '10', '100000', 1, 1),
(14, 'ttttttt', '../assests/images/stock/49091174861bb3dd399dbc.jpg', 11, '7', '66666666666666666666', '555555555555555555', 2, 2),
(15, 'ffffffff', '../assests/images/stock/205629541061bb56328ff88.jpg', 11, '7', '3', '345', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `sub_total` varchar(255) NOT NULL,
  `vat` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `due` varchar(255) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `order_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `client_name`, `client_contact`, `sub_total`, `vat`, `total_amount`, `discount`, `grand_total`, `paid`, `due`, `payment_type`, `payment_status`, `order_status`) VALUES
(1, '2021-07-15', 'John Doe', '9807867564', '2700.00', '351.00', '3051.00', '1000.00', '2051.00', '1000.00', '1051.00', 2, 2, 2),
(2, '2020-07-15', 'John Doe', '9808746573', '3400.00', '442.00', '3842.00', '500.00', '3342.00', '3342', '0', 2, 1, 2),
(5, '2021-07-15', 'kundoJohn Doe', '9807867564', '80200.00', '10426.00', '90626.00', '1000.00', '89626.00', '1000.00', '88626.00', 2, 1, 1),
(6, '2016-07-15', 'John Doe', '9807867564', '40200.00', '5226.00', '45426.00', '1000.00', '44426.00', '1000.00', '43426.00', 2, 1, 1),
(7, '2016-07-15', 'John Doe', '9807867564', '42200.00', '5486.00', '47686.00', '10.00', '47676.00', '10000.00', '37676.00', 3, 1, 1),
(8, '2021-07-15', 'John Doe', '9807867564', '120000.00', '15600.00', '135600.00', '1000.00', '134600.00', '1000.00', '133600.00', 1, 1, 1),
(12, '2021-07-15', 'John Doe', '9807867564', '1800000.00', '234000.00', '2034000.00', '1000.00', '2033000.00', '49000000', '-46967000.00', 2, 1, 1),
(13, '2021-12-19', 'David', '0789841330', '40000.00', '5200.00', '45200.00', '1000.00', '44200.00', '1000.00', '43200.00', 2, 1, 1),
(14, '2021-12-19', 'David', '0789841330', '1480000.00', '192400.00', '1672400.00', '1000.00', '1671400.00', '1000.00', '1670400.00', 2, 1, 1),
(15, '2021-07-15', 'John Doe', '9807867564', '1920000.00', '249600.00', '2169600.00', '1000.00', '2168600.00', '1000000.00', '1168600.00', 1, 1, 1),
(16, '2021-12-20', 'BUNTUBWIMANA', '0780000000', '77000.00', '10010.00', '87010.00', '0', '87010.00', '75000', '12010.00', 2, 1, 1),
(17, '2021-12-20', 'AUGUSTIN', '9807867564', '33000.00', '4290.00', '37290.00', '1000.00', '36290.00', '1000.00', '35290.00', 2, 1, 1),
(18, '2021-12-20', 'vbhnjmkl', '678', '30600.00', '3978.00', '34578.00', '0', '34578.00', '450000', '-415422.00', 2, 1, 1),
(19, '2021-12-20', 'Umurisa', '12', '60800.00', '7904.00', '68704.00', '0', '68704.00', '59800', '8904.00', 2, 2, 1),
(20, '2021-12-20', 'ffhfhhfhf', 'sndnndn', '30600.00', '3978.00', '34578.00', '0', '34578.00', '6778990', '-6744412.00', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `product_id` int(11) NOT NULL DEFAULT 0,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `order_item_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `order_id`, `product_id`, `quantity`, `rate`, `total`, `order_item_status`) VALUES
(1, 1, 1, '1', '1500', '1500.00', 2),
(2, 1, 2, '1', '1200', '1200.00', 2),
(3, 2, 3, '2', '1200', '2400.00', 2),
(4, 2, 4, '1', '1000', '1000.00', 2),
(5, 3, 5, '2', '1200', '2400.00', 2),
(6, 3, 6, '1', '1200', '1200.00', 2),
(7, 4, 5, '1', '1200', '1200.00', 2),
(10, 6, 9, '12', '', '', 1),
(11, 6, 9, '5', '', '', 1),
(12, 6, 9, '5', '', '', 1),
(13, 7, 10, '5', '', '', 1),
(15, 9, 10, '1', '', '', 2),
(16, 9, 9, '2', '', '', 2),
(45, 8, 11, '1', '40000', '40000.00', 1),
(46, 8, 11, '1', '40000', '40000.00', 1),
(47, 8, 11, '1', '40000', '40000.00', 1),
(48, 5, 10, '1', '200', '200.00', 1),
(49, 5, 11, '1', '40000', '40000.00', 1),
(50, 5, 11, '1', '40000', '40000.00', 1),
(51, 12, 10, '9000', '200', '1800000.00', 1),
(52, 13, 11, '1', '40000', '40000.00', 1),
(53, 14, 11, '1', '40000', '40000.00', 1),
(54, 14, 19, '3', '480000', '1440000.00', 1),
(55, 15, 19, '4', '480000', '1920000.00', 1),
(56, 16, 20, '5', '15000', '75000.00', 1),
(57, 16, 10, '10', '200', '2000.00', 1),
(58, 17, 21, '5', '600', '3000.00', 1),
(59, 17, 20, '2', '15000', '30000.00', 1),
(60, 18, 20, '1', '15000', '15000.00', 1),
(61, 18, 21, '1', '600', '600.00', 1),
(62, 18, 20, '1', '15000', '15000.00', 1),
(63, 19, 20, '4', '15000', '60000.00', 1),
(64, 19, 10, '1', '200', '200.00', 1),
(65, 19, 21, '1', '600', '600.00', 1),
(66, 20, 20, '1', '15000', '15000.00', 1),
(67, 20, 21, '1', '600', '600.00', 1),
(68, 20, 20, '1', '15000', '15000.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` text NOT NULL,
  `brand_id` int(11) NOT NULL,
  `categories_id` varchar(250) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_image`, `brand_id`, `categories_id`, `quantity`, `rate`, `active`, `status`) VALUES
(1, 'Half pant', '../assests/images/stock/2847957892502c7200.jpg', 1, '2', '19', '1500', 2, 2),
(2, 'T-Shirt', '../assests/images/stock/163965789252551575.jpg', 2, '2', '9', '1200', 2, 2),
(3, 'Half Pant', '../assests/images/stock/13274578927924974b.jpg', 5, '3', '18', '1200', 2, 2),
(4, 'T-Shirt', '../assests/images/stock/12299578927ace94c5.jpg', 6, '3', '29', '1000', 2, 2),
(5, 'Half Pant', '../assests/images/stock/24937578929c13532e.jpg', 8, '5', '17', '1200', 2, 2),
(6, 'Polo T-Shirt', '../assests/images/stock/10222578929f733dbf.jpg', 9, '5', '29', '1200', 2, 2),
(7, 'Half Pant', '../assests/images/stock/92406141361bb3831e0740.PNG', 11, '7', '28', '1200', 2, 2),
(8, 'Polo T-shirt', '../assests/images/stock/136715789347d1aea6.jpg', 12, '7', '12', '1200', 1, 1),
(9, 'umuceri', '../assests/images/stock/74249247061b9c1c8a5c1a.jpg', 11, '7', '1', '1000', 1, 1),
(10, 'SOCKET', '../assests/images/stock/168947759361b9c372c9eda.jpg', 13, '8', '-9009', '200', 1, 1),
(11, 'Itara', '../assests/images/stock/152488317361ba01c5ec684.jpg', 13, '8', '12', '40000', 1, 1),
(12, 'umupira', '../assests/images/stock/64833731761ba35a86572b.jpg', 14, '9', '-10', '444444', 1, 1),
(13, 'swiitch', '../assests/images/stock/15000412561bb10ca189f1.jpg', 12, '8', '10', '100000', 1, 1),
(14, 'ttttttt', '../assests/images/stock/49091174861bb3dd399dbc.jpg', 11, '7', '66666666666666666666', '555555555555555555', 2, 2),
(15, 'ffffffff', '../assests/images/stock/205629541061bb56328ff88.jpg', 11, '7', '3', '345', 2, 2),
(16, 'umupira', '../assests/images/stock/196563606661bc6a71c2575.jpg', 11, '8', '5', '40000', 1, 1),
(17, 'ipantaro', '../assests/images/stock/162767308761bc6bd19516c.jpg', 15, '8', '10', '50000', 1, 1),
(18, 'umupira', '../assests/images/stock/32299133261be35df75f8e.jpg', 11, '7', '6', '1000', 1, 1),
(19, 'kawunga', '../assests/images/stock/4967721161bf6b855efe2.jpg', 13, '10', '2', '480000', 1, 1),
(20, 'MILANO', '../assests/images/stock/186928889461c043713bb54.jpg', 16, '11', '5', '15000', 1, 1),
(21, 'AMAZI', '../assests/images/stock/199205511961c04a2376587.jpg', 17, '12', '40', '600', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(1, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categories_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
