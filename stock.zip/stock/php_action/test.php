<?php
require_once('core.php');
$quantity=$_POST['quantity'];
$productId=$_POST['product_id'];
$productName=$_POST['product_name'];
$sql = "SELECT product.quantity FROM product WHERE product.product_id =?";
var_dump($quantity);die();
$quantity = $connect->query($sql);
//hano uraba ubonye quantity iri muri stock
$query = "INSERT INTO order_item product_id, quantity=$_POST['']";
//nayo ukore execute yayo
//NYUMA WA IPDATINGE TABLE YA PRODUCT
$reduce = $quantity - quantity(.$_POST[''].);
if ($reduce >=1){
UPDATE product SET quantity = $reduce;}
Else 
	"delete product.product_name from product WHERE quantity=0";
?>